import createHistory from 'history/createHashHistory';
const History = createHistory();

export  {History};