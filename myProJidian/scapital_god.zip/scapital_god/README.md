# enjoy
## start
``` cmd
npm start
```

## server
- static
``` cmd
npm run server
```

- random
``` cmd
npm run server_r
```
